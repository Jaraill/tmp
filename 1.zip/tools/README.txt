= XMind Additional Tools For Windows =

== Associate_XMind_File.CMD ==

Enables launching XMind by double click on a '.xmind' file (i.e. to associate
'.xmind' files with XMind.exe).

Note that you need to execute this command again if the absolute location of
this XMind has changed.


== Install_Additional_Fonts.CMD ==

Installs additional fonts carried along by this XMind distribution.

